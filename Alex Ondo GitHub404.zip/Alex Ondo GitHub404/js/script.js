const searchForm = document.getElementById("search-form");
const searchInput = document.getElementById("search-input");
const errorMessage = document.getElementById("error-message");

searchForm.addEventListener("submit", function (event) {
    if (searchInput.value.trim() === "") {
        event.preventDefault();
        errorMessage.textContent = "Veuillez saisir une recherche.";
        errorMessage.style.color = "red";
        searchInput.style.borderColor = "red";
        searchInput.focus();
    }
});

searchInput.addEventListener("input", function () {
    errorMessage.textContent = "";
    searchInput.style.borderColor = "";
});
